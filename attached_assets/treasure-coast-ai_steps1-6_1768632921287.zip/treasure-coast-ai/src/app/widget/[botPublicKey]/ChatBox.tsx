"use client";

import { useState, useEffect, useRef, useCallback } from "react";
import { isValidUUID } from "@/lib/public/uuid";

type ChatBoxProps = {
  botPublicKey: string;
};

type ChatMessage = {
  role: "user" | "assistant";
  content: string;
  timestamp: string;
};

type HistoryResponse =
  | { ok: true; messages: ChatMessage[] }
  | { ok: false; error: string };

type ChatResponse =
  | { ok: true; conversationPublicId: string; assistant: { content: string } }
  | { ok: false; error: string };

export function ChatBox({ botPublicKey }: ChatBoxProps) {
  const [message, setMessage] = useState("");
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [isLoadingHistory, setIsLoadingHistory] = useState(false);
  const [isSending, setIsSending] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const messagesEndRef = useRef<HTMLDivElement>(null);
  const storageKey = `tca_conversation_${botPublicKey}`;

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages.length]);

  const fetchHistory = useCallback(
    async (convId: string) => {
      setIsLoadingHistory(true);
      setError(null);

      try {
        const res = await fetch(
          `/api/public/conversations/${encodeURIComponent(convId)}/messages?botPublicKey=${encodeURIComponent(
            botPublicKey
          )}`,
          { cache: "no-store" }
        );

        const data = (await res
          .json()
          .catch(() => ({ ok: false, error: "Invalid response" }))) as HistoryResponse;

        if (data.ok) {
          setMessages(data.messages);
          return;
        }

        if (res.status === 400 || res.status === 404) {
          localStorage.removeItem(storageKey);
          setMessages([]);
          return;
        }

        setError("Failed to load message history");
      } catch {
        setError("Failed to load message history");
      } finally {
        setIsLoadingHistory(false);
      }
    },
    [botPublicKey, storageKey]
  );

  useEffect(() => {
    const convId = localStorage.getItem(storageKey);
    if (!convId) return;

    if (!isValidUUID(convId)) {
      localStorage.removeItem(storageKey);
      return;
    }

    fetchHistory(convId);
  }, [storageKey, fetchHistory]);

  const handleSend = async () => {
    const trimmed = message.trim();
    if (!trimmed || isSending) return;

    setIsSending(true);
    setError(null);

    const userMessage: ChatMessage = {
      role: "user",
      content: trimmed,
      timestamp: new Date().toISOString()
    };

    setMessages((prev) => [...prev, userMessage]);
    setMessage("");

    try {
      const storedConvId = localStorage.getItem(storageKey);

      const res = await fetch("/api/public/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          botPublicKey,
          conversationPublicId: storedConvId,
          message: trimmed
        })
      });

      const data = (await res
        .json()
        .catch(() => ({ ok: false, error: "Invalid response" }))) as ChatResponse;

      if (!data.ok) {
        setError(data.error || "Failed to send message");
        return;
      }

      if (!isValidUUID(data.conversationPublicId) || typeof data.assistant?.content !== "string") {
        setError("Invalid response from server");
        return;
      }

      const wasNewConversation = !storedConvId;
      localStorage.setItem(storageKey, data.conversationPublicId);

      const assistantMessage: ChatMessage = {
        role: "assistant",
        content: data.assistant.content,
        timestamp: new Date().toISOString()
      };

      setMessages((prev) => [...prev, assistantMessage]);

      if (wasNewConversation) {
        fetchHistory(data.conversationPublicId);
      }
    } catch {
      setError("Failed to send message");
    } finally {
      setIsSending(false);
    }
  };

  return (
    <div className="space-y-4">
      {isLoadingHistory && (
        <div className="rounded-lg border border-white/10 bg-white/5 p-4 text-center">
          <p className="text-sm text-white/60">Loading conversation...</p>
        </div>
      )}

      {!isLoadingHistory && messages.length > 0 && (
        <div className="max-h-96 space-y-3 overflow-y-auto rounded-lg border border-white/10 bg-white/5 p-4">
          {messages.map((msg, idx) => (
            <div
              key={`${msg.timestamp}:${idx}`}
              className={`flex ${msg.role === "user" ? "justify-end" : "justify-start"}`}
            >
              <div
                className={`max-w-[80%] rounded-lg px-4 py-2 ${
                  msg.role === "user"
                    ? "bg-white text-black"
                    : "border border-white/10 bg-white/5 text-white/90"
                }`}
              >
                <p className="text-sm">{msg.content}</p>
              </div>
            </div>
          ))}
          <div ref={messagesEndRef} />
        </div>
      )}

      {error && (
        <div className="rounded-lg border border-red-500/20 bg-red-500/10 p-3">
          <p className="text-sm text-red-400">{error}</p>
        </div>
      )}

      <div className="flex gap-2">
        <input
          type="text"
          value={message}
          onChange={(e) => setMessage(e.target.value)}
          onKeyDown={(e) => e.key === "Enter" && handleSend()}
          placeholder="Type a message..."
          disabled={isSending || isLoadingHistory}
          className="flex-1 rounded-md border border-white/15 bg-white/5 px-4 py-2 text-sm text-white placeholder-white/40 focus:border-white/30 focus:outline-none disabled:opacity-50"
        />
        <button
          onClick={handleSend}
          disabled={isSending || isLoadingHistory || !message.trim()}
          className="rounded-md bg-white px-4 py-2 text-sm font-medium text-black hover:opacity-90 disabled:opacity-50"
        >
          {isSending ? "..." : "Send"}
        </button>
      </div>
    </div>
  );
}
