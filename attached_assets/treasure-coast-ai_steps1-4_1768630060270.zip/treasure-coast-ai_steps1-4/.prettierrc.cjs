module.exports = {
  semi: true,
  singleQuote: false,
  printWidth: 100,
  trailingComma: "all",
  plugins: ["prettier-plugin-tailwindcss"]
};
