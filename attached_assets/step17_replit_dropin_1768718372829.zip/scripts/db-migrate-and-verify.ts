#!/usr/bin/env tsx

import { PrismaClient } from "@prisma/client";
import { execSync } from "child_process";

async function main() {
  console.log("[DB MIGRATE] Starting migration + verification...");

  if (!process.env.DATABASE_URL) {
    console.error("[DB MIGRATE] ERROR: DATABASE_URL environment variable is not set");
    process.exit(1);
  }

  try {
    console.log("[DB MIGRATE] Running migrations (prisma migrate deploy)...");
    // Uses the package.json script: "db:migrate": "prisma migrate deploy"
    execSync("pnpm db:migrate", { stdio: "inherit" });
    console.log("[DB MIGRATE] Migrations completed successfully");
  } catch (error) {
    console.error("[DB MIGRATE] ERROR: Migration failed", error);
    process.exit(1);
  }

  const prisma = new PrismaClient();

  try {
    console.log("[DB MIGRATE] Verifying database connectivity...");
    await prisma.$connect();

    // Schema-agnostic connectivity check (does not assume any model exists)
    await prisma.$queryRaw`SELECT 1`;

    console.log("[DB MIGRATE] Database connected successfully");
    console.log("[DB MIGRATE] All checks passed ✓");
  } catch (error) {
    console.error("[DB MIGRATE] ERROR: Database connectivity verification failed", error);
    process.exit(1);
  } finally {
    await prisma.$disconnect();
  }
}

main().catch((error) => {
  console.error("[DB MIGRATE] Unexpected error:", error);
  process.exit(1);
});
