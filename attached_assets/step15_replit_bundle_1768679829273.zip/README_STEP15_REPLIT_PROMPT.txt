STEP 15 — E2E REVENUE LOOP TESTS (Playwright)

WHAT THIS BUNDLE CONTAINS
1) playwright.config.ts (NEW)
2) tests/e2e/revenue-loop.spec.ts (NEW)
3) patches/ChatBox.data-testid.patch.diff (apply manually)
4) patches/package.json.playwright.patch.diff (apply manually)

WHY PATCH FILES?
- You already have src/app/widget/[botPublicKey]/ChatBox.tsx and package.json.
- Replit can paste edits directly; these patch files show exactly what to change.

REPLIT STEPS
A) Add NEW files
- Create: playwright.config.ts  (paste from bundle)
- Create: tests/e2e/revenue-loop.spec.ts  (paste from bundle)

B) Modify existing files
1) package.json
- Add to devDependencies: "@playwright/test": "^1.48.0"
- Add to scripts: "test:e2e": "playwright test"
(Use patches/package.json.playwright.patch.diff as the guide.)

2) src/app/widget/[botPublicKey]/ChatBox.tsx
- Find the bottom input/button block inside the <div className="flex gap-2"> containing the chat input.
- Add:
  data-testid="chat-input" to the <input>
  data-testid="chat-send" to the <button>
(Use patches/ChatBox.data-testid.patch.diff as the guide.)

C) Install deps + browsers
pnpm add -D @playwright/test
npx playwright install chromium

D) QA gates
pnpm lint
pnpm typecheck

E) Run E2E
pnpm test:e2e

EXPECTED
- 2 tests pass:
  1) complete revenue flow via API endpoints
  2) widget UI smoke test (input visible + send disabled until text)

NOTES
- The E2E test auto-finds the first ACTIVE bot in Prisma.
- It uses Host: example.com headers to match allowlist logic.
- It runs with 1 worker for determinism.
