import { describe, expect, it } from "vitest";
import { BrandingSchema } from "../../src/lib/validators/branding";

// If your repo uses Jest instead of Vitest, replace the imports with:
// import { describe, it, expect } from "@jest/globals";

describe("BrandingSchema", () => {
  it("accepts a minimal valid payload", () => {
    const input = {
      whiteLabelEnabled: false,
      brandCompanyName: null,
      brandLogoUrl: null,
      brandPrimaryColor: "#6366f1",
      showPoweredBy: true,
      customDomain: null,
    };

    const parsed = BrandingSchema.parse(input);
    expect(parsed.whiteLabelEnabled).toBe(false);
    expect(parsed.brandPrimaryColor).toBe("#6366f1");
  });

  it("rejects invalid hex colors", () => {
    const input = {
      whiteLabelEnabled: true,
      brandCompanyName: "Acme",
      brandLogoUrl: "https://example.com/logo.png",
      brandPrimaryColor: "blue",
      showPoweredBy: true,
      customDomain: "chat.example.com",
    };

    expect(() => BrandingSchema.parse(input)).toThrow();
  });

  it("rejects protocol in customDomain", () => {
    const input = {
      whiteLabelEnabled: true,
      brandCompanyName: "Acme",
      brandLogoUrl: "https://example.com/logo.png",
      brandPrimaryColor: "#ff5733",
      showPoweredBy: false,
      customDomain: "https://example.com",
    };

    expect(() => BrandingSchema.parse(input)).toThrow();
  });
});
