import { test, expect } from "@playwright/test";

// NOTE: This is a skeleton.
// Wire it into your existing auth helper (e.g., loginAsAgencyOwner(page)).

test.describe("Step 25: White-label branding settings", () => {
  test("page renders and shows key controls", async ({ page }) => {
    // TODO: login helper here
    // await loginAsAgencyOwner(page);

    await page.goto("/dashboard/settings/branding");

    // Headings
    await expect(page.getByRole("heading", { name: /white-label branding/i })).toBeVisible();

    // Toggle
    await expect(page.getByLabel(/enable white-label/i)).toBeVisible();

    // Inputs
    await expect(page.getByLabel(/company name/i)).toBeVisible();
    await expect(page.getByLabel(/logo url/i)).toBeVisible();
    await expect(page.getByLabel(/primary brand color/i)).toBeVisible();
    await expect(page.getByLabel(/custom domain/i)).toBeVisible();
  });
});
