# Step 25 — White-label Branding (Org-scoped) — File Pack

This pack is meant to be dropped into your Treasure Coast AI repo as guidance **or** used as a reference for Replit AI.

## What’s included
- Zod validator for branding settings
- Org-scoped API route: `/api/org/branding` (GET/PUT)
- Client helper to apply CSS vars in dashboard
- SQL migration example
- Unit + E2E test skeletons
- A ready-to-paste Replit prompt: `replit_prompt_step25.txt`

## IMPORTANT
This pack **does not** contain your existing repo files. It only contains new files and documentation.
Use the Replit prompt to apply the required modifications safely.

## Suggested commands (after changes)
- `pnpm prisma generate`
- `pnpm prisma migrate dev --name step25_org_branding`
- `pnpm lint`
- `pnpm typecheck`
- `pnpm test`
- `pnpm test:e2e`
- `pnpm build`

