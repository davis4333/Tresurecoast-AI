import { z } from "zod";

// Strict hex color validation (#RRGGBB format)
const hexColorRegex = /^#[0-9A-Fa-f]{6}$/;

// Domain validation (domain only, no protocol). Examples: example.com, chat.example.co
const domainRegex = /^(?:[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?\.)+[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?$/i;

/**
 * Org-level branding settings.
 * NOTE: We allow empty strings in the UI payload and normalize them to null in the route.
 */
export const BrandingSchema = z.object({
  whiteLabelEnabled: z.boolean(),
  brandCompanyName: z.string().max(80).nullable().or(z.literal("")),
  brandLogoUrl: z.string().url().nullable().or(z.literal("")),
  brandPrimaryColor: z.string().regex(hexColorRegex, "Must be a valid hex color (#RRGGBB)"),
  showPoweredBy: z.boolean(),
  customDomain: z.string().regex(domainRegex, "Must be a valid domain (e.g., example.com)").nullable().or(z.literal("")),
});

export type BrandingInput = z.infer<typeof BrandingSchema>;

export const BrandingResponseSchema = z.object({
  ok: z.literal(true),
  branding: z.object({
    whiteLabelEnabled: z.boolean(),
    brandCompanyName: z.string().nullable(),
    brandLogoUrl: z.string().nullable(),
    brandPrimaryColor: z.string(),
    showPoweredBy: z.boolean(),
    customDomain: z.string().nullable(),
  }),
});

export type BrandingResponse = z.infer<typeof BrandingResponseSchema>;
