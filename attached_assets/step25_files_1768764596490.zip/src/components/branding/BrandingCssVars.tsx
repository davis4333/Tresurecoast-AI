"use client";

import { useEffect } from "react";

/**
 * Applies org branding CSS variables after login.
 * Safe to include once at the root of your authenticated app layout.
 */
export function BrandingCssVars() {
  useEffect(() => {
    let cancelled = false;

    async function apply() {
      try {
        const res = await fetch("/api/org/branding", { method: "GET" });
        if (!res.ok) return;
        const data = await res.json();
        if (cancelled) return;

        const enabled = Boolean(data?.branding?.whiteLabelEnabled);
        const primary = enabled && data?.branding?.brandPrimaryColor ? data.branding.brandPrimaryColor : "#6366f1";

        document.documentElement.style.setProperty("--tca-brand-primary", primary);
      } catch {
        // silent fail - branding is optional
      }
    }

    apply();

    return () => {
      cancelled = true;
    };
  }, []);

  return null;
}
