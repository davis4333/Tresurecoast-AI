import { NextRequest, NextResponse } from "next/server";
import { auth } from "@clerk/nextjs/server";
import { ZodError } from "zod";
import { BrandingSchema } from "@/lib/validators/branding";
// Adjust this import to your project (some repos use '@/lib/db' or '@/lib/prisma')
import { prisma } from "@/lib/prisma";

export const dynamic = "force-dynamic";

function jsonError(
  requestId: string,
  status: number,
  error: string,
  message: string,
  details?: unknown
) {
  return NextResponse.json({ ok: false, error, message, requestId, details }, { status });
}

async function getOrgForUser(userId: string) {
  // If your app supports multiple org memberships, you should decide how "current org" is chosen.
  // This matches the existing pattern used in many TCA steps: first membership.
  return prisma.organizationMember.findFirst({
    where: { clerkUserId: userId },
    include: {
      organization: {
        select: {
          id: true,
          whiteLabelEnabled: true,
          brandCompanyName: true,
          brandLogoUrl: true,
          brandPrimaryColor: true,
          showPoweredBy: true,
          customDomain: true,
        },
      },
    },
  });
}

// GET /api/org/branding
export async function GET(_req: NextRequest) {
  const requestId = crypto.randomUUID();

  try {
    const { userId } = await auth();
    if (!userId) return jsonError(requestId, 401, "unauthorized", "Authentication required");

    const membership = await getOrgForUser(userId);
    if (!membership?.organization) {
      return jsonError(requestId, 404, "org_not_found", "Organization not found");
    }

    return NextResponse.json({
      ok: true,
      branding: {
        whiteLabelEnabled: membership.organization.whiteLabelEnabled,
        brandCompanyName: membership.organization.brandCompanyName,
        brandLogoUrl: membership.organization.brandLogoUrl,
        brandPrimaryColor: membership.organization.brandPrimaryColor,
        showPoweredBy: membership.organization.showPoweredBy,
        customDomain: membership.organization.customDomain,
      },
      requestId,
    });
  } catch (err) {
    return jsonError(requestId, 500, "internal_error", "Failed to retrieve branding");
  }
}

// PUT /api/org/branding
export async function PUT(req: NextRequest) {
  const requestId = crypto.randomUUID();

  try {
    const { userId } = await auth();
    if (!userId) return jsonError(requestId, 401, "unauthorized", "Authentication required");

    const membership = await prisma.organizationMember.findFirst({
      where: { clerkUserId: userId },
      select: {
        role: true,
        organizationId: true,
        organization: { select: { customDomain: true } },
      },
    });

    if (!membership) {
      return jsonError(requestId, 404, "org_not_found", "Organization not found");
    }

    // Only owners/admins can update branding
    if (membership.role !== "AGENCY_OWNER" && membership.role !== "AGENCY_ADMIN") {
      return jsonError(
        requestId,
        403,
        "forbidden",
        "Only organization owners/admins can update branding"
      );
    }

    const body = await req.json();
    const parsed = BrandingSchema.parse(body);

    // Normalize empty strings to null
    const normalized = {
      whiteLabelEnabled: parsed.whiteLabelEnabled,
      brandCompanyName: parsed.brandCompanyName || null,
      brandLogoUrl: parsed.brandLogoUrl || null,
      brandPrimaryColor: parsed.brandPrimaryColor,
      showPoweredBy: parsed.showPoweredBy,
      customDomain: parsed.customDomain || null,
    };

    // Enforce customDomain uniqueness if changing
    if (normalized.customDomain && normalized.customDomain !== membership.organization.customDomain) {
      const existing = await prisma.organization.findUnique({
        where: { customDomain: normalized.customDomain },
        select: { id: true },
      });

      if (existing && existing.id !== membership.organizationId) {
        return jsonError(
          requestId,
          409,
          "domain_taken",
          "This custom domain is already in use by another organization"
        );
      }
    }

    const updated = await prisma.organization.update({
      where: { id: membership.organizationId },
      data: normalized,
      select: {
        whiteLabelEnabled: true,
        brandCompanyName: true,
        brandLogoUrl: true,
        brandPrimaryColor: true,
        showPoweredBy: true,
        customDomain: true,
      },
    });

    return NextResponse.json({
      ok: true,
      branding: updated,
      requestId,
    });
  } catch (err) {
    if (err instanceof ZodError) {
      return jsonError(requestId, 400, "validation_error", "Invalid branding data", err.errors);
    }
    return jsonError(requestId, 500, "internal_error", "Failed to update branding");
  }
}
