# Step 25 Pack — Patch Notes (What to edit in your repo)

This zip contains **only the new files + a sample SQL migration + test skeletons**.
You still need to apply edits to a few existing files in your repo.
Use `replit_prompt_step25.txt` as the canonical instruction to Replit AI.

## Files in this pack (new)
- `src/lib/validators/branding.ts`
- `src/app/api/org/branding/route.ts`
- `src/components/branding/BrandingCssVars.tsx`
- `prisma/migrations/step25_add_org_branding_fields/migration.sql`
- `tests/unit/brandingSchema.test.ts` (Vitest-style, easy swap to Jest)
- `tests/e2e/branding-settings.spec.ts` (Playwright skeleton)

## Existing files you must modify (in your repo)
1. `prisma/schema.prisma`
   - Add Organization fields:
     - `whiteLabelEnabled Boolean @default(false)`
     - `brandCompanyName String?`
     - `brandLogoUrl String?`
     - `brandPrimaryColor String @default("#6366f1")`
     - `showPoweredBy Boolean @default(true)`
     - `customDomain String? @unique`

2. `src/app/globals.css`
   - Add CSS variable:
     - `--tca-brand-primary: #6366f1;`

3. Root authenticated layout (where your app shell lives)
   - Import and render `<BrandingCssVars />` once.
   - If you keep it in `src/components/branding/BrandingCssVars.tsx`, import from there.

4. Widget config endpoint: `src/app/api/public/widget-config/route.ts`
   - Extend Prisma query to include organization branding.
   - Add `branding` object to response.

5. Widget UI: `src/app/widget/[botPublicKey]/ChatBox.tsx`
   - Read `config.branding`.
   - Theme header + send button with `brandPrimaryColor`.
   - Show logo/company name if enabled.
   - Conditionally show "Powered by" footer based on `showPoweredBy`.

6. Settings page route
   - Create `/dashboard/settings/branding` (or your equivalent settings path) and implement the UI.

## Import paths to check
- This pack uses `import { prisma } from "@/lib/prisma";`
  - If your repo uses `@/lib/db`, update accordingly.

