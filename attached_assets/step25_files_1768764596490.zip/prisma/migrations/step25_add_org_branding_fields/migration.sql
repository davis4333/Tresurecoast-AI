-- Step 25: Organization white-label branding fields
-- NOTE: If you use Prisma Migrate normally, Prisma will generate this for you.
-- This file is provided for deterministic review and for environments where you use migrate deploy.

ALTER TABLE "organizations" ADD COLUMN IF NOT EXISTS "whiteLabelEnabled" BOOLEAN NOT NULL DEFAULT false;
ALTER TABLE "organizations" ADD COLUMN IF NOT EXISTS "brandCompanyName" TEXT;
ALTER TABLE "organizations" ADD COLUMN IF NOT EXISTS "brandLogoUrl" TEXT;
ALTER TABLE "organizations" ADD COLUMN IF NOT EXISTS "brandPrimaryColor" TEXT NOT NULL DEFAULT '#6366f1';
ALTER TABLE "organizations" ADD COLUMN IF NOT EXISTS "showPoweredBy" BOOLEAN NOT NULL DEFAULT true;
ALTER TABLE "organizations" ADD COLUMN IF NOT EXISTS "customDomain" TEXT;

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_indexes WHERE indexname = 'organizations_customDomain_key'
  ) THEN
    CREATE UNIQUE INDEX "organizations_customDomain_key" ON "organizations"("customDomain");
  END IF;
END $$;
